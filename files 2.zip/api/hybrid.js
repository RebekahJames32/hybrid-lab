// api/hybrid.js
//
// Tiny backend that runs on Vercel. It receives the chosen animal + dinosaur
// from the website, looks up rich info about each parent species, builds a
// detailed prompt for Claude, and returns a richly-described hybrid creature.
// The API key lives only on the server, never in the browser.

// ========== RICH CREATURE DATA ==========
// We keep this on the server (instead of trusting whatever the client sends)
// so nobody can inject random text into the AI prompt by tampering with
// requests. Names are the only thing the client can choose.
const ANIMALS = {
  'Wolf': { description: 'Apex pack hunters with extraordinary endurance and intelligence.', traits: ['Coordinated pack hunting', 'Smell 100× sharper than human', 'Long-distance endurance running', 'Crushing bite force'], habitat: 'Forests, tundra, and mountain ranges', length_ft: 5, weight_lbs: 80, diet: 'carnivore' },
  'Eagle': { description: 'Master aerial hunters with vision capable of spotting prey from a mile away.', traits: ['Vision 8× sharper than human', 'Talon grip force around 400 PSI', 'Wingspan up to 7 feet', 'Dives at 100+ mph'], habitat: 'Mountains, coasts, and open forests', length_ft: 3, weight_lbs: 10, diet: 'carnivore' },
  'Tiger': { description: 'The largest of all wild cats — solitary, stealthy, and immensely powerful.', traits: ['Stripes are unique like fingerprints', 'Can leap 30 feet horizontally', 'Excellent night vision', 'Powerful crushing bite'], habitat: 'Asian jungles, mangrove swamps, and grasslands', length_ft: 10, weight_lbs: 500, diet: 'carnivore' },
  'Shark': { description: 'Ancient ocean predators that have prowled the seas for over 400 million years.', traits: ['Senses electric fields of prey', 'Constantly grows replacement teeth', 'Detects blood from a quarter mile away', 'Some species never stop swimming'], habitat: 'All ocean environments worldwide', length_ft: 15, weight_lbs: 1200, diet: 'carnivore' },
  'Octopus': { description: 'Highly intelligent invertebrates with eight independently-thinking arms.', traits: ['Three hearts and blue blood', 'Instant color and texture camouflage', 'Each arm has its own neurons', 'Squeezes through any gap larger than its beak'], habitat: 'Ocean floors, reefs, and tidal pools', length_ft: 16, weight_lbs: 25, diet: 'carnivore' },
  'Snake': { description: 'Limbless predators that smell with their tongues and swallow prey whole.', traits: ['Detects body heat through pit organs', 'Unhinges jaw to swallow large prey', 'Some inject venom in milliseconds', 'Climbs, swims, and burrows'], habitat: 'Almost every environment except polar regions', length_ft: 15, weight_lbs: 150, diet: 'carnivore' },
  'Elephant': { description: 'Earth\'s largest land animal — incredibly intelligent and emotionally complex.', traits: ['Trunk has over 40,000 muscles', 'Communicates over miles via low-frequency rumbles', 'Excellent long-term memory', 'Tusks can weigh hundreds of pounds'], habitat: 'African savannas and Asian forests', length_ft: 20, weight_lbs: 12000, diet: 'herbivore' },
  'Lion': { description: 'The only truly social big cat, hunting in coordinated prides.', traits: ['Roar audible from 5 miles away', 'Females do most of the hunting', 'Powerful neck muscles for taking down large prey', 'Mane signals strength to rivals'], habitat: 'African grasslands and dry savannas', length_ft: 8, weight_lbs: 420, diet: 'carnivore' },
  'Bear': { description: 'Massive omnivores combining brute strength with surprising speed.', traits: ['Sprints 35 mph despite huge size', 'Hibernates for months without eating', 'Powerful claws for digging and climbing', 'Smell 7× better than a bloodhound'], habitat: 'Forests, mountains, and arctic tundra', length_ft: 8, weight_lbs: 900, diet: 'omnivore' },
  'Gorilla': { description: 'Gentle giants with the strength of ten humans and remarkable intelligence.', traits: ['Can lift 1,800+ pounds', 'Uses tools and recognizes itself in mirrors', 'Communicates via 25+ vocalizations', 'Lives in close-knit family groups'], habitat: 'African rainforests and bamboo forests', length_ft: 6, weight_lbs: 400, diet: 'herbivore' },
  'Crocodile': { description: 'Ancient reptiles essentially unchanged for 200 million years.', traits: ['Bite force of 3,700 PSI — the strongest measured', 'Holds breath underwater for an hour', 'Signature death-roll spinning attack', 'Heart shunts blood to digest large meals'], habitat: 'Tropical rivers, swamps, and estuaries', length_ft: 17, weight_lbs: 1000, diet: 'carnivore' },
  'Scorpion': { description: 'Armored arachnids that glow under UV light and have prowled Earth for 430 million years.', traits: ['Pincers crush prey instantly', 'Tail stinger injects neurotoxic venom', 'Glows blue-green under UV light', 'Can survive a year without food'], habitat: 'Deserts, forests, and dark caves', length_ft: 0.5, weight_lbs: 1, diet: 'carnivore' },
  'Owl': { description: 'Silent night-flying hunters with 270-degree neck rotation.', traits: ['Specially fringed feathers for silent flight', 'Hears prey moving under snow', 'Rotates head 270 degrees', 'Sees in near-total darkness'], habitat: 'Forests, deserts, mountains, and tundra', length_ft: 2, weight_lbs: 4, diet: 'carnivore' },
  'Cheetah': { description: 'The fastest land animal, built entirely for explosive speed.', traits: ['Accelerates 0–60 mph in three seconds', 'Top speed near 70 mph', 'Non-retractable claws act like cleats', 'Tail acts as a rudder while turning'], habitat: 'African grasslands and semi-arid plains', length_ft: 7, weight_lbs: 120, diet: 'carnivore' },
  'Whale': { description: 'The largest animals to ever exist, with songs that travel hundreds of miles.', traits: ['Heart can weigh as much as a car', 'Communicates across oceans via low frequencies', 'Holds breath for 90+ minutes', 'Some species live over 200 years'], habitat: 'All oceans, from polar to tropical waters', length_ft: 80, weight_lbs: 300000, diet: 'carnivore' },
  'Hawk': { description: 'Fierce daytime hunters with telescopic vision and rapid pursuit speed.', traits: ['Detects movement from a mile away', 'Stoops at 150+ mph', 'Talons pierce thick fur', 'Sees in the ultraviolet spectrum'], habitat: 'Open country, forests, and cliffs', length_ft: 2, weight_lbs: 3, diet: 'carnivore' }
};

const DINOS = {
  'T-Rex': { description: 'The Tyrant Lizard King — a 40-foot apex predator of the late Cretaceous with the strongest bite of any land animal that ever lived.', traits: ['Bite force around 8,000 PSI — bone-crushing', 'Vision 13× sharper than human, with binocular depth perception', 'Tiny but powerfully muscled arms could lift 400 lbs', 'Could run 12–17 mph despite weighing 9 tons'], period: 'Late Cretaceous (68–66 million years ago)', length: '40 ft (12 m)', height: '12 ft at the hip', weight: '9 tons (18,000 lbs)', diet: 'Carnivore — ate Triceratops, Edmontosaurus, and possibly carrion', fun_fact: 'Brain twice the size of any other carnivorous dinosaur — and grew the size of a school bus in just 18 years.' },
  'Velociraptor': { description: 'Turkey-sized, fully feathered pack hunter with a retractable sickle claw on each foot — far smaller and smarter than the movies suggest.', traits: ['3-inch sickle claw on the second toe of each foot', 'Body completely covered in feathers (proven by quill knobs on bones)', 'Brain-to-body ratio similar to modern birds', 'Hunted in coordinated packs using vocal calls'], period: 'Late Cretaceous (75–71 million years ago)', length: '6.8 ft (2 m) — most of it tail', height: '1.6 ft at the hip', weight: '33 lbs (15 kg)', diet: 'Carnivore — small mammals, lizards, and juvenile dinosaurs', fun_fact: 'A famous fossil shows a Velociraptor locked in mid-fight with a Protoceratops, both buried alive by a sand dune.' },
  'Triceratops': { description: 'Three-horned tank-like herbivore with a 7-foot skull — one of the only dinosaurs known to have stood its ground against T-Rex.', traits: ['Three forward-pointing horns up to 4 ft long', 'Bony neck frill possibly used for display and defense', 'Beak-like mouth shredded tough cycads and palms', 'Walked on four pillar-like legs'], period: 'Late Cretaceous (68–66 million years ago)', length: '30 ft (9 m)', height: '10 ft at the shoulder', weight: '12 tons (24,000 lbs)', diet: 'Herbivore — tough plants, palms, ferns', fun_fact: 'Skull alone could weigh up to 1 ton — one of the largest skulls of any land animal in history.' },
  'Stegosaurus': { description: 'Plate-backed plant-eater with a brain the size of a walnut and a 4-foot-spiked tail called the thagomizer.', traits: ['17 bony back plates that may have flushed with blood for display', 'Spiked tail (thagomizer) could swing at 50 mph', 'Brain only 80 grams in a 5-ton body', 'Walked slowly on four legs, hind legs longer than front'], period: 'Late Jurassic (155–150 million years ago)', length: '30 ft (9 m)', height: '9 ft at the back plates', weight: '5 tons (10,000 lbs)', diet: 'Herbivore — low ferns, mosses, and cycads', fun_fact: 'Fossil evidence shows Stegosaur tail spikes piercing Allosaurus bones — proof its tail really was used in combat.' },
  'Brachiosaurus': { description: 'Towering long-necked giant that browsed treetops 40 feet up — its front legs were unusually longer than its back legs.', traits: ['Stood 40 feet tall — taller than a 4-story building', 'Heart had to pump blood up a 30-foot neck', 'Nostrils on top of head, originally thought to be for snorkeling', 'Spoon-shaped teeth stripped leaves from high branches'], period: 'Late Jurassic (154–153 million years ago)', length: '85 ft (26 m)', height: '40 ft (12 m) tall', weight: '50 tons (100,000 lbs)', diet: 'Herbivore — high tree foliage, ginkgoes, conifers', fun_fact: 'Ate around 880 lbs of plants every single day to fuel its massive body.' },
  'Pterodactyl': { description: 'Flying reptile (technically a pterosaur, not a dinosaur!) with leathery wings stretched between an extremely long fourth finger and the body.', traits: ['Wingspan up to 35 ft in the largest species (Quetzalcoatlus)', 'Hollow, paper-thin bones for flight', 'Walked on all fours when grounded, like a bat', 'Some species had elaborate head crests for display'], period: 'Late Jurassic to Late Cretaceous (150–66 million years ago)', length: '3.5 ft body length (typical species)', wingspan: '5 ft (small) to 35 ft (largest)', weight: '2 lbs to 550 lbs depending on species', diet: 'Carnivore — fish, insects, small vertebrates', fun_fact: 'Largest pterosaurs were as tall as a giraffe when standing — and could still fly.' },
  'Spinosaurus': { description: 'Largest predatory dinosaur ever discovered — semi-aquatic with a 7-foot sail on its back and crocodile-like jaws full of conical teeth.', traits: ['Even larger than T-Rex (50 ft long)', 'Crocodile-like snout with pressure-sensing pits for catching fish', 'Dense bones acted like ballast for swimming', 'Paddle-like tail for underwater propulsion'], period: 'Mid Cretaceous (99–93 million years ago)', length: '50 ft (15 m)', height: '12 ft at the sail\'s peak', weight: '7–20 tons (estimates vary)', diet: 'Piscivore/Carnivore — large fish, possibly small dinosaurs', fun_fact: 'Only known dinosaur thought to have spent most of its life in water, like a giant prehistoric crocodile.' },
  'Ankylosaurus': { description: 'Living tank covered head-to-toe in interlocking bony armor, with a 100-pound bone club at the end of its tail.', traits: ['Body sheathed in fused bony plates (osteoderms)', 'Tail club could shatter T-Rex shinbones', 'Even its eyelids were armored', 'Low-slung body made it nearly impossible to flip'], period: 'Late Cretaceous (68–66 million years ago)', length: '20–26 ft (6–8 m)', height: '5.5 ft at the shoulder', weight: '6 tons (12,000 lbs)', diet: 'Herbivore — low-growing plants and ferns', fun_fact: 'The tail club was so heavy it required massive tendons in the tail just to swing it.' },
  'Allosaurus': { description: 'Fierce Jurassic apex predator with serrated teeth like steak knives and three powerful clawed fingers on each hand.', traits: ['Skull built like a hatchet for slashing attacks', '70 serrated teeth, replaced continuously throughout life', 'Three-fingered hands with 6-inch curved claws', 'Possibly hunted in groups to take down sauropods'], period: 'Late Jurassic (155–145 million years ago)', length: '32 ft (9.7 m)', height: '9 ft at the hip', weight: '2.3 tons (4,600 lbs)', diet: 'Carnivore — Stegosaurus, juvenile sauropods, Camptosaurus', fun_fact: 'More Allosaurus skeletons have been found than any other large theropod — making it the best-known Jurassic predator.' },
  'Diplodocus': { description: 'Long-necked giant whose 45-foot whip-tail could supposedly crack like a bullwhip at supersonic speeds.', traits: ['90 feet long, mostly neck and tail', 'Whip-tail tip may have broken the sound barrier', 'Pencil-shaped teeth at the front of the mouth stripped leaves', 'Walked on four pillar-like legs, neck held mostly horizontal'], period: 'Late Jurassic (154–152 million years ago)', length: '90 ft (27 m)', height: '16 ft at the hip', weight: '15 tons (30,000 lbs)', diet: 'Herbivore — ferns, ginkgoes, and conifer needles', fun_fact: 'Despite being nearly 100 ft long, its head was only the size of a horse\'s — and its brain the size of a fist.' },
  'Parasaurolophus': { description: 'Crested duck-billed dinosaur whose hollow 6-foot head crest produced low foghorn-like calls audible for miles.', traits: ['Hollow tube-like head crest connected to nasal passages', 'Produced loud trumpet-like sounds for herd communication', 'Could walk on either two or four legs', 'Lived in large social herds'], period: 'Late Cretaceous (76–73 million years ago)', length: '31 ft (9.5 m)', height: '8 ft at the hip', weight: '2.5 tons (5,000 lbs)', diet: 'Herbivore — leaves, twigs, pine needles ground by hundreds of teeth', fun_fact: 'Scientists have built working models of the crest — it produces a deep B-flat note like a tuba.' },
  'Iguanodon': { description: 'Plant-eater with a defensive thumb spike and a beak — one of the very first dinosaurs ever named (1825).', traits: ['Conical defensive spike on each thumb (originally mistaken for a nose horn!)', 'Could walk on two or four legs depending on activity', 'Hand-sized teeth ground tough vegetation', 'Lived in herds across Europe, Asia, and North America'], period: 'Early Cretaceous (140–110 million years ago)', length: '33 ft (10 m)', height: '9 ft at the hip', weight: '3.5 tons (7,000 lbs)', diet: 'Herbivore — horsetails, conifers, cycads', fun_fact: 'When first discovered, the thumb spike was placed on its nose like a rhino — it took 50 years to figure out the right spot.' }
};

// ========== HANDLER ==========
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Only POST requests allowed' });
  }

  const { animal, dinosaur } = req.body || {};

  if (!animal || !dinosaur) {
    return res.status(400).json({ error: 'Both animal and dinosaur are required' });
  }

  // Reject anything we don't recognize — this prevents prompt injection
  // through fake "creature" names with malicious descriptions
  const animalData = ANIMALS[animal];
  const dinoData = DINOS[dinosaur];
  if (!animalData || !dinoData) {
    return res.status(400).json({ error: 'Unknown animal or dinosaur' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'API key not configured on server' });
  }

  const prompt = buildPrompt(animal, animalData, dinosaur, dinoData);

  try {
    const anthropicResponse = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1500,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!anthropicResponse.ok) {
      const errText = await anthropicResponse.text();
      console.error('Anthropic API error:', anthropicResponse.status, errText);
      return res.status(502).json({ error: 'AI service returned an error' });
    }

    const data = await anthropicResponse.json();
    const textBlock = data.content.find(b => b.type === 'text');
    let raw = textBlock ? textBlock.text.trim() : '';

    // Strip code fences if Claude wrapped the JSON
    raw = raw.replace(/^```json\s*/i, '').replace(/^```\s*/, '').replace(/```\s*$/, '').trim();

    let hybrid;
    try {
      hybrid = JSON.parse(raw);
    } catch (parseErr) {
      console.error('Failed to parse AI response as JSON:', raw);
      return res.status(502).json({ error: 'AI returned malformed data' });
    }

    return res.status(200).json(hybrid);
  } catch (err) {
    console.error('Unexpected error:', err);
    return res.status(500).json({ error: 'Something went wrong generating the hybrid' });
  }
}

// ========== PROMPT BUILDER ==========
function buildPrompt(animalName, animalData, dinoName, dinoData) {
  return `You are a senior cryptozoologist documenting a brand-new hybrid creature for a scientific journal. Two parent species have been genetically fused.

PARENT A — ${animalName}
${animalData.description}
Notable traits:
${animalData.traits.map(t => `- ${t}`).join('\n')}
Native habitat: ${animalData.habitat}
Typical length: ${animalData.length_ft} ft
Typical weight: ${animalData.weight_lbs} lbs
Diet: ${animalData.diet}

PARENT B — ${dinoName}
${dinoData.description}
Notable traits:
${dinoData.traits.map(t => `- ${t}`).join('\n')}
Era: ${dinoData.period}
Length: ${dinoData.length}
Weight: ${dinoData.weight}
Diet: ${dinoData.diet}
Fun fact: ${dinoData.fun_fact}

Invent a richly imagined hybrid that draws meaningful, specific traits from BOTH parents. Be vivid, sensory, and confident. Make it feel like a real documented species, not a cartoon mash-up.

NAMING — read this carefully, this is the most important part.
DO NOT use the lazy [first-half-of-A][second-half-of-B] template. Examples of names you must NEVER produce:
- "Wolfraptor", "Sharkasaurus", "Tigertops", "Eagledon", "Lionasaurus"

These are predictable and boring. Instead, choose ONE of these naming approaches and execute it well:

1. INVENTED LATIN/GREEK SCIENTIFIC NAME — sounds scholarly. Examples: "Cryptodon", "Vexipteryx", "Lupotherium", "Skarnodax", "Therimorph"
2. MYTHOLOGICAL PROPER NOUN — sounds legendary. Examples: "Vrenkar", "The Morrigan", "Hessian", "Auld Crowfang", "Karthaag"
3. EVOCATIVE ENGLISH DESCRIPTOR — sounds poetic. Examples: "Pale Walker", "Bone Sovereign", "The Sundering Maw", "Ironcrest", "Hollowclaw"
4. PURE INVENTED WORD — sounds visceral. Examples: "Skarn", "Mraeg", "Velka", "Kthar", "Drovan"

The name should feel like it was discovered in an ancient bestiary, not generated by smashing parent names together. Be bold and creative.

Respond with ONLY a valid JSON object (no markdown fences, no commentary):

{
  "name": "Creative name following the rules above",
  "scientific_name": "A fake Latin binomial like 'Lupotyrannus magnificus'",
  "description": "4-6 vivid sentences describing the hybrid's appearance, movement, sounds, and presence. Be specific and sensory — use concrete details like 'iridescent scales', 'low rumbling growl', 'three-toed gait'. Reference traits from BOTH parents.",
  "size": "Length and height (e.g., '18 ft long, 9 ft at the shoulder')",
  "weight": "Estimated weight (e.g., '2.4 tons')",
  "diet": "Diet category and 1-2 favored prey/foods",
  "habitat": "Specific environment description (10-15 words)",
  "behavior": "2-3 sentences on temperament, social structure, and hunting/foraging style",
  "traits": [
    {"icon": "single emoji", "name": "TRAIT NAME (max 3 words, all caps)", "detail": "one sentence describing this special ability or anatomical feature"},
    {"icon": "single emoji", "name": "...", "detail": "..."},
    {"icon": "single emoji", "name": "...", "detail": "..."}
  ],
  "weakness": "A single specific vulnerability that makes the creature feel real (e.g., 'Cannot regulate body temperature below 40°F')",
  "discovery_lore": "1-2 sentences describing where, when, and how field researchers first documented this specimen",
  "danger_level": "A creative danger rating (e.g., 'Class IV — Apex Predator', 'Surprisingly Cuddly', 'Near-Mythical Threat')"
}`;
}
